package com.example.kotlinfinalprojmoviesapp.data.roomdb

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.kotlinfinalprojmoviesapp.data.model.*

@Dao
interface DAO {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
     suspend fun addMovieToDB(movie:MovieItemInRecycler)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addAllMoviesToDB(movies:List<MovieItemInRecycler>)


    @Query("SELECT * FROM movies ORDER BY name")
    fun getMovies():LiveData<List<MovieItemInRecycler>>

    @Query("SELECT * FROM popularmovies")
    fun getPopularMovies():LiveData<List<PopularMovie>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addPopularMoviesToDB(movies:List<PopularMovie>)

    @Query("SELECT * FROM upcomingmovies")
    fun getUpcomingMovies():LiveData<List<UpcomingMovie>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addUpcomingMoviesToDB(movies:List<UpcomingMovie>)

    @Delete()
    suspend fun DeleteMovieFromDB(movie:MovieItemInRecycler)

    @Insert
    suspend fun addFavoriteMovie(movie:FavoriteMoviesModel)

    @Delete
    suspend fun removeFavoriteMovie(movie: FavoriteMoviesModel)

    @Update
    suspend fun updateFavoriteMovie(movie: FavoriteMoviesModel)

    @Query("SELECT * FROM favorite_movies")
    fun getFavoriteMovies(): LiveData<List<FavoriteMoviesModel>>
}