package com.example.kotlinfinalprojmoviesapp.data.repository

import android.app.Application
import androidx.lifecycle.LiveData
import com.example.kotlinfinalprojmoviesapp.data.model.FavoriteMoviesModel
import com.example.kotlinfinalprojmoviesapp.data.model.MovieItemInRecycler
import com.example.kotlinfinalprojmoviesapp.data.roomdb.DAO
import com.example.kotlinfinalprojmoviesapp.data.roomdb.MoviesDB
import com.example.kotlinfinalprojmoviesapp.remote_db.MovieDataSource
import il.co.syntax.finalkotlinproject.utils.performFetchingAndSaving
import il.co.syntax.finalkotlinproject.utils.Resource
import il.co.syntax.finalkotlinproject.utils.Success
import io.grpc.util.OutlierDetectionLoadBalancer.OutlierDetectionLoadBalancerConfig.SuccessRateEjection
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MovieRepository @Inject constructor(
    private val remoteDataMovies:MovieDataSource,
    private val localDataMovies:DAO
) {

    fun getMovies() = performFetchingAndSaving(
        { localDataMovies.getMovies() },
        { remoteDataMovies.getMovies() },
        { localDataMovies.addAllMoviesToDB(it.results) }
    )


        suspend fun addMovie(movie:MovieItemInRecycler){
        localDataMovies.addMovieToDB(movie)
    }
        suspend fun deleteMovie(movie:MovieItemInRecycler){
        localDataMovies.DeleteMovieFromDB(movie)
    }
    suspend fun addFavoriteMovie(movie: FavoriteMoviesModel) {
        localDataMovies.addFavoriteMovie(movie)
    }

    suspend fun updateFavoriteMovie(movie:FavoriteMoviesModel){
        localDataMovies.updateFavoriteMovie(movie)
    }

    suspend fun removeFavoriteMovie(movie: FavoriteMoviesModel) {
        localDataMovies.removeFavoriteMovie(movie)
    }

    fun getFavoriteMovies(): LiveData<List<FavoriteMoviesModel>> {
        return localDataMovies.getFavoriteMovies()
    }

    fun getPopularMovies() = performFetchingAndSaving(
        { localDataMovies.getPopularMovies()},
        {remoteDataMovies.GetPopularMovies()},
        {localDataMovies.addPopularMoviesToDB(it.results)}
    )

    fun getUpcomingMovies() = performFetchingAndSaving(
        { localDataMovies.getUpcomingMovies()},
        {remoteDataMovies.GetUpcomingMovies()},
        {localDataMovies.addUpcomingMoviesToDB(it.results)}
    )
}