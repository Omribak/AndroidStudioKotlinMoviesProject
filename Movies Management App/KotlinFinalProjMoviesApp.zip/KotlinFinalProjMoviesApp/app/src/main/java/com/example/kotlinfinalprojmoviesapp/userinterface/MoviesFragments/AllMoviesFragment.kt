package com.example.kotlinfinalprojmoviesapp.userinterface.MoviesFragments

import android.app.AlertDialog
import android.content.DialogInterface
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.room.Delete
import com.example.kotlinfinalprojmoviesapp.R
import com.example.kotlinfinalprojmoviesapp.data.model.FavoriteMoviesModel
import com.example.kotlinfinalprojmoviesapp.databinding.AllMoviesBinding
import com.example.kotlinfinalprojmoviesapp.userinterface.Adapters.MovieAdapter
import com.example.kotlinfinalprojmoviesapp.userinterface.ViewModelClass
import dagger.hilt.android.AndroidEntryPoint
import il.co.syntax.finalkotlinproject.utils.Loading
import il.co.syntax.finalkotlinproject.utils.Resource
import il.co.syntax.finalkotlinproject.utils.Success
import kotlinx.coroutines.launch

@AndroidEntryPoint
class AllMoviesFragment:Fragment() {
    private val viewModel: ViewModelClass by activityViewModels()

    private lateinit var adapter: MovieAdapter

    private var _binding : AllMoviesBinding?=null
    private val binding get() = _binding!!
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        setHasOptionsMenu(true)
        _binding = AllMoviesBinding.inflate(inflater,container,false)
        binding.addMovie.setOnClickListener{
            findNavController().navigate(R.id.action_allMoviesFragment_to_addMovieFragment)
        }
        binding.questionMarkBtn.setOnClickListener{
            findNavController().navigate(R.id.action_allMoviesFragment_to_informationFragment)
        }
        binding.favoriteBtn.setOnClickListener{
            findNavController().navigate(R.id.action_allMoviesFragment_to_favoriteMoviesFragment)
        }


        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.recycler.layoutManager = LinearLayoutManager(requireContext())
        adapter = MovieAdapter(emptyList(), object : MovieAdapter.MovieItemListener {
                    override fun MovieShortClick(index: Int) {
                        val currmovie = (binding.recycler.adapter as MovieAdapter).MoviePosAt(index)
                        viewModel.SetMovieDetailsOnScreen(currmovie)
                        findNavController().navigate(R.id.action_allMoviesFragment_to_detailedSingleMovieFragment2, bundleOf("movie" to index))
                    }

                    override fun movieFavBtn(index: Int) {

                        val currmovie = (binding.recycler.adapter as MovieAdapter).MoviePosAt(index)
                        val favoriteMovie = FavoriteMoviesModel(
                            title = currmovie.title,
                            posterPath = if (currmovie.isFromApi) {
                                "https://image.tmdb.org/t/p/original" + currmovie.poster_path
                            } else {
                                currmovie.poster_path
                            }
                        )
                        lifecycleScope.launch {
                            viewModel.addFavoriteMovie(favoriteMovie)
                        }
                    }

                    override fun MovieLongClick(index: Int) {
                        val DeleteDialog : AlertDialog.Builder = AlertDialog.Builder(requireContext())
                        DeleteDialog.apply{
                            setTitle(getString(R.string.delete_movie_all_movies))
                            setMessage(getString(R.string.are_you_sure_delete))
                            val positiveButton =
                                setPositiveButton(getString(R.string.yes_delete_all_movies)
                                ) { p0, p1 ->
                                    val currmovie = (binding.recycler.adapter as MovieAdapter).MoviePosAt(index)
                                    lifecycleScope.launch {
                                        viewModel.deleteMovie(currmovie)
                                    }
                                }
                            setNegativeButton(getString(R.string.no_delete_all_movies), { p0, p1 ->
                            })


                            val removedialog = DeleteDialog.create()
                            removedialog.show()
                        }
                    }
        })
        binding.recycler.adapter = adapter
        viewModel.movies.observe(viewLifecycleOwner){
            when(it.status){
                is Loading-> Toast.makeText(requireContext(),getString(R.string.movies_are_loading),Toast.LENGTH_LONG).show()
                is Success->{
                    if(!it.status.data.isNullOrEmpty()){
                        adapter.setMovies(it.status.data)
                    }
                }
                is il.co.syntax.finalkotlinproject.utils.Error->{
                    Toast.makeText(requireContext(),it.status.message,Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        inflater.inflate(R.menu.movies_menu, menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if(item.itemId==R.id.sign_out_menu){
            viewModel.ExitAapp()
            findNavController().navigate(R.id.action_allMoviesFragment_to_LoginFragment)
        }
        if(item.itemId==R.id.contact_us_menu){
            findNavController().navigate(R.id.action_allMoviesFragment_to_contactUsFragment)
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding=null
    }
}