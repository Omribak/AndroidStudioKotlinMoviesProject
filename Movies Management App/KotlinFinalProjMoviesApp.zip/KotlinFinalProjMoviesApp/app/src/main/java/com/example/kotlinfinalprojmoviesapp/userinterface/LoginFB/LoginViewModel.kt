package com.example.kotlinfinalprojmoviesapp.userinterface.LoginFB

import androidx.lifecycle.*
import com.example.kotlinfinalprojmoviesapp.data.model.UserFB
import com.example.kotlinfinalprojmoviesapp.data.repository.AuthenticationRepository
import il.co.syntax.finalkotlinproject.utils.Resource
import kotlinx.coroutines.launch

class LoginViewModel(private val repository:AuthenticationRepository):ViewModel() {

    private val _LoginStatus= MutableLiveData<Resource<UserFB>>()
    val LoginStatus : LiveData<Resource<UserFB>> = _LoginStatus

    private val _fetchUser = MutableLiveData<Resource<UserFB>>()
    val fetchUser : LiveData<Resource<UserFB>> = _fetchUser

    init{
        viewModelScope.launch {
            _fetchUser.postValue(Resource.loading())
            _fetchUser.postValue(repository.fetchUser())
        }
    }

    fun EnterUser(email:String,password:String){
        if(email.isEmpty() || password.isEmpty()){
            _LoginStatus.postValue(Resource.error("One of the fields are empty!"))
        }else{
            _LoginStatus.postValue(Resource.loading())
            viewModelScope.launch {
                val result = repository.login(email,password)
                _LoginStatus.postValue(result)
            }
        }
    }

    class LoginVMFactory(private val repos:AuthenticationRepository): ViewModelProvider.NewInstanceFactory(){
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return LoginViewModel(repos) as T
        }
    }
}