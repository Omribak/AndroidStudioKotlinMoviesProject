package com.example.kotlinfinalprojmoviesapp.remote_db

import com.example.kotlinfinalprojmoviesapp.data.model.AllMovies
import com.example.kotlinfinalprojmoviesapp.data.model.MovieItemInRecycler
import il.co.syntax.finalkotlinproject.utils.Resource
import il.co.syntax.finalkotlinproject.utils.Status
import il.co.syntax.finalkotlinproject.utils.Success
import javax.inject.Inject

class MovieDataSource @Inject constructor(

    private val moviesService : MoviesRetrofitService2):BaseDataSource() {
    suspend fun getMovies(): Resource<AllMovies> {
        return getResult {
            moviesService.getAllMovies()
        }.let { resource ->
            if (resource.status is Success) {
                val movies = resource.status.data?.results?.map { movie ->
                    movie.copy(isFromApi = true)
                } ?: emptyList()
                val modifiedAllMovies = AllMovies(movies)
                Resource.success(modifiedAllMovies)
            } else {
                Resource.error("Unknown error", null)
            }
        }
    }
    suspend fun GetPopularMovies() = getResult { moviesService.getPopularMovies() }

    suspend fun GetUpcomingMovies() = getResult { moviesService.getUpcomingMovies() }



}



