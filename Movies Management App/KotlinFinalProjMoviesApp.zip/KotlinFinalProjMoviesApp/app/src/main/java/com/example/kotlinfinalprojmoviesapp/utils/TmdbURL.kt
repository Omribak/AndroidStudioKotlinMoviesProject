package com.example.kotlinfinalprojmoviesapp.utils

class TmdbURL {

    companion object{
        const val API_URL = "https://api.themoviedb.org/"
    }
}