package com.example.kotlinfinalprojmoviesapp.userinterface.Adapters

import android.view.LayoutInflater
import android.view.View
import android.view.View.OnClickListener
import android.view.View.OnLongClickListener
import android.view.ViewGroup
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.kotlinfinalprojmoviesapp.R
import com.example.kotlinfinalprojmoviesapp.data.model.FavoriteMoviesModel
import com.example.kotlinfinalprojmoviesapp.databinding.FavoriteMovieItemInRecyclerBinding
import com.example.kotlinfinalprojmoviesapp.databinding.MovieRecyclerItemLayoutBinding

class FavoritesAdapter(val favmovies:List<FavoriteMoviesModel>,val callBack:FavoriteMoviesListener):RecyclerView.Adapter<FavoritesAdapter.FavoritesViewHolder>(){

    interface FavoriteMoviesListener{
        fun onClickRemove(index:Int)
        fun onClickEdit(index:Int)
    }

    inner class FavoritesViewHolder(private val binding:FavoriteMovieItemInRecyclerBinding):
            RecyclerView.ViewHolder(binding.root),OnLongClickListener{
                fun bindToRecycler(movieItemInRecycler: FavoriteMoviesModel){
                    binding.editButton.setOnClickListener{
                        callBack.onClickEdit(adapterPosition)
                    }
                    binding.itemMovieTitle.text = movieItemInRecycler.title
                    Glide.with(binding.root).load(movieItemInRecycler.posterPath).into(binding.itemMovieImage)
                }
        init{
            binding.root.setOnLongClickListener(this)
        }

        override fun onLongClick(p0: View?): Boolean {
            callBack.onClickRemove(adapterPosition)
            return true
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavoritesViewHolder =
        FavoritesViewHolder(FavoriteMovieItemInRecyclerBinding.inflate(LayoutInflater.from(parent.context),parent,false))

    override fun getItemCount() = favmovies.size


    override fun onBindViewHolder(holder: FavoritesViewHolder, position: Int) =
        holder.bindToRecycler(favmovies[position])

    fun FavMoviePos(position: Int) =
        favmovies[position]
}