package com.example.kotlinfinalprojmoviesapp.userinterface.MoviesFragments

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.kotlinfinalprojmoviesapp.R
import com.example.kotlinfinalprojmoviesapp.databinding.FavoriteMoviesLayoutBinding
import com.example.kotlinfinalprojmoviesapp.userinterface.Adapters.FavoritesAdapter
import com.example.kotlinfinalprojmoviesapp.userinterface.Adapters.MovieAdapter
import com.example.kotlinfinalprojmoviesapp.userinterface.ViewModelClass
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class FavoriteMoviesFragment:Fragment() {
    private val viewModel: ViewModelClass by activityViewModels()
    private var _binding :FavoriteMoviesLayoutBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FavoriteMoviesLayoutBinding.inflate(inflater,container,false)
        return binding.root

        return super.onCreateView(inflater, container, savedInstanceState)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.favoritemovies.observe(viewLifecycleOwner){
            binding.favoriteRecycler.adapter = FavoritesAdapter(it,object:FavoritesAdapter.FavoriteMoviesListener{
                override fun onClickRemove(index: Int) {
                    val DeleteDialog : AlertDialog.Builder = AlertDialog.Builder(requireContext())
                    DeleteDialog.apply{
                        setTitle(getString(R.string.delete_movie_all_movies))
                        setMessage(getString(R.string.are_you_sure_delete))
                        val positiveButton =
                            setPositiveButton(getString(R.string.yes_delete_all_movies)
                            ) { p0, p1 ->
                                val favmovie = (binding.favoriteRecycler.adapter as FavoritesAdapter).FavMoviePos(index)
                                lifecycleScope.launch {
                                    viewModel.deleteFavMovie(favmovie)
                                }
                            }
                        setNegativeButton(getString(R.string.no_delete_all_movies), { p0, p1 ->
                        })


                        val removedialog = DeleteDialog.create()
                        removedialog.show()
                    }
                }

                override fun onClickEdit(index: Int) {
                    val favmovie = (binding.favoriteRecycler.adapter as FavoritesAdapter).FavMoviePos(index)
                    viewModel.SetEditFavMovie(favmovie)
                    findNavController().navigate(R.id.action_favoriteMoviesFragment_to_editFavoriteFragment)
                }
            })
            binding.favoriteRecycler.layoutManager=LinearLayoutManager(requireContext())

        }
        viewModel.EditFavMovie.observe(viewLifecycleOwner){

        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding=null
    }
}