package com.example.kotlinfinalprojmoviesapp.data.roomdb

import android.content.Context
import androidx.constraintlayout.utils.widget.MockView
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.kotlinfinalprojmoviesapp.data.model.FavoriteMoviesModel
import com.example.kotlinfinalprojmoviesapp.data.model.MovieItemInRecycler
import com.example.kotlinfinalprojmoviesapp.data.model.PopularMovie
import com.example.kotlinfinalprojmoviesapp.data.model.UpcomingMovie

@Database(entities = [MovieItemInRecycler::class, FavoriteMoviesModel::class,PopularMovie::class,UpcomingMovie::class],version=6, exportSchema = false)
abstract class MoviesDB : RoomDatabase() {

 abstract fun MoviesDAO() : DAO

 companion object{

  @Volatile
  private var instance:MoviesDB?=null

  fun getDatabase(context:Context) = instance ?: synchronized(this){
   Room.databaseBuilder(context.applicationContext,MoviesDB::class.java,"Movies_DB").fallbackToDestructiveMigration().build().also{
    instance = it
   }
  }
 }
}