package com.example.kotlinfinalprojmoviesapp.data.repository

import com.example.kotlinfinalprojmoviesapp.data.model.UserFB
import il.co.syntax.finalkotlinproject.utils.Resource

interface AuthenticationRepository {

    suspend fun fetchUser():Resource<UserFB>
    suspend fun login(email:String,password:String):Resource<UserFB>
    suspend fun createUser(username:String,email:String,password:String):Resource<UserFB>
    fun logout()
}