package com.example.kotlinfinalprojmoviesapp.userinterface.MoviesFragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.bumptech.glide.Glide
import com.example.kotlinfinalprojmoviesapp.databinding.SingleMovieDetailsBinding
import com.example.kotlinfinalprojmoviesapp.userinterface.ViewModelClass
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class DetailedSingleMovieFragment:Fragment() {

    val viewModel: ViewModelClass by activityViewModels()
    var _binding : SingleMovieDetailsBinding?=null
    val binding get() = _binding!!
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = SingleMovieDetailsBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.ShortClickedMovie.observe(viewLifecycleOwner){
            binding.movieTitleText.text = it.title
            binding.movieDescriptionText.text = it.overview
            val ImageURL = if (it.isFromApi) {
                "https://image.tmdb.org/t/p/original" + it.poster_path
            } else {
                it.poster_path
            }
            Glide.with(requireContext()).load(ImageURL).circleCrop().into(binding.moviePhotoImage)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding=null
    }
}