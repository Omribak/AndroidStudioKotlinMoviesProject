package com.example.kotlinfinalprojmoviesapp.userinterface.Adapters

import android.view.LayoutInflater
import android.view.View
import android.view.View.OnClickListener
import android.view.View.OnLongClickListener
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.kotlinfinalprojmoviesapp.R
import com.example.kotlinfinalprojmoviesapp.data.model.MovieItemInRecycler
import com.example.kotlinfinalprojmoviesapp.databinding.MovieRecyclerItemLayoutBinding

    class MovieAdapter(var movies:List<MovieItemInRecycler>, val callBack: MovieItemListener):RecyclerView.Adapter<MovieAdapter.MovieItemViewHolder>() {


        interface MovieItemListener{
        fun MovieShortClick(index:Int)
        fun MovieLongClick(index:Int)
        fun movieFavBtn(index:Int)
    }


    inner class MovieItemViewHolder(private val binding: MovieRecyclerItemLayoutBinding):
            RecyclerView.ViewHolder(binding.root),OnClickListener,OnLongClickListener{

        init{
            binding.root.setOnClickListener(this)
            binding.root.setOnLongClickListener(this)
            binding.addToFavoriteRecycler.setOnClickListener{
                callBack.movieFavBtn(adapterPosition)
            }
        }

                fun bind(movie: MovieItemInRecycler){
                    val ImageURL = if (movie.isFromApi) {
                        "https://image.tmdb.org/t/p/original" + movie.poster_path
                    } else {
                        movie.poster_path
                    }
                    binding.movieTitle.text = movie.title
                    if(movie.release_date!=null){
                        binding.movieRelease.text = binding.root.context.getString(R.string.release_date_all_movies) + movie.release_date


                    }
                    if(movie.popularity!=null){
                        binding.moviePopularity.text = binding.root.context.getString(R.string.movie_popularity_all_movies) + movie.popularity.toString()                    }
                    if(movie.adult!=null){
                        binding.movieAdult.text = binding.root.context.getString(R.string.for_adult_all_movies) + movie.adult.toString()
                    }
                    Glide.with(binding.root).load(ImageURL).into(binding.movieImage)
                    binding.root.visibility = View.VISIBLE
                }
        override fun onClick(p0: View?) {
            callBack.MovieShortClick(adapterPosition)
        }

        override fun onLongClick(p0: View?): Boolean {
            callBack.MovieLongClick(adapterPosition)
            return true
        }

    }
    fun setMovies(movies: Collection<MovieItemInRecycler>?) {
        val updatedList = movies?.map { movie ->
            if (movie.isFromApi) {
                movie.copy(isFromApi = true)
            } else {
                movie.copy(isFromApi = false)
            }
        } ?: emptyList()
        this.movies = updatedList
        notifyDataSetChanged()
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int)=
        MovieItemViewHolder(MovieRecyclerItemLayoutBinding.inflate(LayoutInflater.from(parent.context),parent,false))

    override fun getItemCount()= movies.size

    override fun onBindViewHolder(holder: MovieItemViewHolder, position: Int) {
        holder.bind(movies[position])
    }

    fun MoviePosAt(position: Int) =
        movies[position]
}