package com.example.kotlinfinalprojmoviesapp.data.repository.AuthFBRepos

import com.example.kotlinfinalprojmoviesapp.data.model.UserFB
import com.example.kotlinfinalprojmoviesapp.data.repository.AuthenticationRepository
import com.example.kotlinfinalprojmoviesapp.utils.SafeCall
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.auth.User
import il.co.syntax.finalkotlinproject.utils.Resource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import javax.inject.Inject


class AuthReposFB @Inject constructor(): AuthenticationRepository {

    private val firebaseAuth = FirebaseAuth.getInstance()
    private val userRef = FirebaseFirestore.getInstance().collection("usersApp")
    override suspend fun fetchUser(): Resource<UserFB> {
        return withContext(Dispatchers.IO){
            SafeCall {
                val currentuser = userRef.document(firebaseAuth.currentUser!!.uid).get().await().toObject(UserFB::class.java)
                Resource.success(currentuser!!)
            }
        }
    }

    override suspend fun login(email: String, password: String): Resource<UserFB> {
        return withContext(Dispatchers.IO){
            SafeCall {
                val resultFB = firebaseAuth.signInWithEmailAndPassword(email,password).await()
                val user = userRef.document(resultFB.user?.uid!!).get().await().toObject(UserFB::class.java)!!
                Resource.success(user)
            }
        }
    }

    override suspend fun createUser(
        username: String,
        email: String,
        password: String
    ):Resource<UserFB> {
        return withContext(Dispatchers.IO){
            SafeCall {
                val RegisteredUser = firebaseAuth.createUserWithEmailAndPassword(email,password).await()
                val FBuserId = RegisteredUser.user?.uid!!
                val newAppUser = UserFB(username,email)
                userRef.document(FBuserId).set(newAppUser).await()
                Resource.success(newAppUser)
            }
        }
    }

    override fun logout() {
        firebaseAuth.signOut()
    }
}