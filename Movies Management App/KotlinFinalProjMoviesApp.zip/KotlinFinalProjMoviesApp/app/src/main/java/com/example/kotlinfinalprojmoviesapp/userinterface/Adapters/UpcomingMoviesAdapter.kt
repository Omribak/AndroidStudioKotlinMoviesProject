package com.example.kotlinfinalprojmoviesapp.userinterface.Adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.kotlinfinalprojmoviesapp.data.model.PopularMovie
import com.example.kotlinfinalprojmoviesapp.databinding.PopularMoviesItemRecyclerBinding
import com.example.kotlinfinalprojmoviesapp.data.model.PopularMovies
import com.example.kotlinfinalprojmoviesapp.data.model.UpcomingMovie
import com.example.kotlinfinalprojmoviesapp.data.model.UpcomingMovies
import com.example.kotlinfinalprojmoviesapp.databinding.UpcomingMoviesItemRecyclerBinding
import com.example.kotlinfinalprojmoviesapp.databinding.UpcomingMoviesLayoutBinding


class UpcomingMoviesAdapter(private var movies: List<UpcomingMovie>) :
    RecyclerView.Adapter<UpcomingMoviesAdapter.MovieViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieViewHolder {
        val binding = UpcomingMoviesItemRecyclerBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return MovieViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
        val movie = movies[position]
        holder.bind(movie)
    }

    fun setUpcomingMovies(upcomingmovies: Collection<UpcomingMovie>){
        movies = upcomingmovies.toList()
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = movies.size

    inner class MovieViewHolder(private val binding:UpcomingMoviesItemRecyclerBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(movie: UpcomingMovie) {
            binding.movieTitle.text = movie.title
            val imageURL = "https://image.tmdb.org/t/p/original" + movie.poster_path
            Glide.with(binding.root).load(imageURL).into(binding.movieImage)
        }
    }
}

