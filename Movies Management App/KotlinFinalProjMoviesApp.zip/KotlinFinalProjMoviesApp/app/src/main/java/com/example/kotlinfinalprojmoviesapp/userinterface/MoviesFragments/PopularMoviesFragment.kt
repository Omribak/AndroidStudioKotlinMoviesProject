package com.example.kotlinfinalprojmoviesapp.userinterface.MoviesFragments

import com.example.kotlinfinalprojmoviesapp.databinding.PopularMoviesLayoutBinding

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.kotlinfinalprojmoviesapp.R
import com.example.kotlinfinalprojmoviesapp.data.model.PopularMovie
import com.example.kotlinfinalprojmoviesapp.userinterface.Adapters.MovieAdapter
import com.example.kotlinfinalprojmoviesapp.userinterface.Adapters.PopularMoviesAdapter
import com.example.kotlinfinalprojmoviesapp.userinterface.ViewModelClass
import dagger.hilt.android.AndroidEntryPoint
import il.co.syntax.finalkotlinproject.utils.Loading
import il.co.syntax.finalkotlinproject.utils.Success

@AndroidEntryPoint
class PopularMoviesFragment : Fragment() {

    private lateinit var popularAdapter : PopularMoviesAdapter
    private var _binding: PopularMoviesLayoutBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ViewModelClass by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = PopularMoviesLayoutBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        popularAdapter = PopularMoviesAdapter(emptyList())
        binding.popularMoviesRecycler.layoutManager = GridLayoutManager(requireContext(),3)
        binding.popularMoviesRecycler.adapter = popularAdapter
        viewModel.popularmovies.observe(viewLifecycleOwner){
            when(it.status){
                is Loading-> Toast.makeText(requireContext(),getString(R.string.popular_loading), Toast.LENGTH_LONG).show()
                is Success ->{
                    if(!it.status.data.isNullOrEmpty()){
                        popularAdapter.setPopularMovies(it.status.data)
                    }
                }
                is il.co.syntax.finalkotlinproject.utils.Error->{
                    Toast.makeText(requireContext(),it.status.message, Toast.LENGTH_LONG).show()
                }
            }

        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
