package com.example.kotlinfinalprojmoviesapp.HiltInjection

import android.content.Context
import com.example.kotlinfinalprojmoviesapp.data.repository.AuthFBRepos.AuthReposFB
import com.example.kotlinfinalprojmoviesapp.data.roomdb.MoviesDB
import com.example.kotlinfinalprojmoviesapp.remote_db.MoviesRetrofitService2
import com.example.kotlinfinalprojmoviesapp.utils.TmdbURL
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
class AppModule {

    @Provides
    @Singleton
    fun ProvideRetrofitModule(gson:Gson):Retrofit{
        return Retrofit.Builder().baseUrl(TmdbURL.API_URL)
            .addConverterFactory(GsonConverterFactory.create(gson)).build()
    }

    @Provides
    fun ProvideGson():Gson = GsonBuilder().create()

    @Provides
    fun ProvideMoviesService(retrofit: Retrofit) :
            MoviesRetrofitService2 = retrofit.create(MoviesRetrofitService2::class.java)

    @Provides
    @Singleton
    fun ProvideLocalRoomDB(@ApplicationContext appContext:Context):MoviesDB =
        MoviesDB.getDatabase(appContext)

    @Provides
    @Singleton
    fun ProvideDAO(database:MoviesDB) = database.MoviesDAO()

    @Provides
    fun provideAuthReposFB(): AuthReposFB {
        return AuthReposFB()
    }
}