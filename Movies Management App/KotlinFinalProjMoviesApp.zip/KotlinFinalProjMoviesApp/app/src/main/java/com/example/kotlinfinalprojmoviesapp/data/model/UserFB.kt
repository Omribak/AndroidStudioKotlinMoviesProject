package com.example.kotlinfinalprojmoviesapp.data.model

data class UserFB(
    val name:String="",
    val email:String=""
) {
}