package com.example.kotlinfinalprojmoviesapp.data.model

data class UpcomingMovies (
    val results: List<UpcomingMovie>
){
}