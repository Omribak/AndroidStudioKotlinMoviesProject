package com.example.kotlinfinalprojmoviesapp.userinterface.MoviesFragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.kotlinfinalprojmoviesapp.R
import com.example.kotlinfinalprojmoviesapp.databinding.UpcomingMoviesLayoutBinding
import com.example.kotlinfinalprojmoviesapp.userinterface.Adapters.UpcomingMoviesAdapter
import com.example.kotlinfinalprojmoviesapp.userinterface.ViewModelClass
import dagger.hilt.android.AndroidEntryPoint
import il.co.syntax.finalkotlinproject.utils.Loading
import il.co.syntax.finalkotlinproject.utils.Success

@AndroidEntryPoint
class UpcomingMoviesFragment : Fragment() {

    private lateinit var upcomingAdapter : UpcomingMoviesAdapter
    private var _binding: UpcomingMoviesLayoutBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ViewModelClass by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = UpcomingMoviesLayoutBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
       upcomingAdapter = UpcomingMoviesAdapter(emptyList())
        binding.upcomingMoviesRecycler.layoutManager = GridLayoutManager(requireContext(),3)
        binding.upcomingMoviesRecycler.adapter=upcomingAdapter
        viewModel.upcomingmovies.observe(viewLifecycleOwner){
            when(it.status){
                is Loading-> Toast.makeText(requireContext(),getString(R.string.upcomin_loading), Toast.LENGTH_LONG).show()
                is Success ->{
                    if(!it.status.data.isNullOrEmpty()){
                        upcomingAdapter.setUpcomingMovies(it.status.data)
                    }
                }
                is il.co.syntax.finalkotlinproject.utils.Error->{
                    Toast.makeText(requireContext(),it.status.message, Toast.LENGTH_LONG).show()
                }
            }

        }

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}







