package com.example.kotlinfinalprojmoviesapp.userinterface.MoviesFragments

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.example.kotlinfinalprojmoviesapp.data.model.MovieItemInRecycler
import com.example.kotlinfinalprojmoviesapp.R
import com.example.kotlinfinalprojmoviesapp.databinding.AddMovieBinding
import com.example.kotlinfinalprojmoviesapp.userinterface.ViewModelClass
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class AddMovieFragment:Fragment() {
    private val viewModel: ViewModelClass by activityViewModels()
    private var MovieImageUri:Uri?=null
    private var _binding : AddMovieBinding?=null
    private val binding get() = _binding!!
    val chooseMovieImageLauncher:ActivityResultLauncher<Array<String>> =
        registerForActivityResult(ActivityResultContracts.OpenDocument()){
            binding.resultImage.setImageURI(it)
            requireActivity().contentResolver.takePersistableUriPermission(it!!, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            MovieImageUri=it
        }
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = AddMovieBinding.inflate(inflater,container,false)
        binding.addToListBtn.setOnClickListener{
            val movie = MovieItemInRecycler(null,binding.movieName.text.toString(),binding.movieDesc.text.toString(),MovieImageUri.toString(),null,null,null,false)
            lifecycleScope.launch {
                viewModel.addMovie(movie)
            }
            findNavController().navigate(R.id.action_addMovieFragment_to_allMoviesFragment)
        }
        binding.chooseImage.setOnClickListener{
            chooseMovieImageLauncher.launch(arrayOf("image/*"))
        }
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}