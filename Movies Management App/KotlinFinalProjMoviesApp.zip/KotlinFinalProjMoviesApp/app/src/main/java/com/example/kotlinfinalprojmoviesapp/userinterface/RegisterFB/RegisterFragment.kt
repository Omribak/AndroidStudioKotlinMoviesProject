package com.example.kotlinfinalprojmoviesapp.userinterface.RegisterFB

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.example.kotlinfinalprojmoviesapp.R
import com.example.kotlinfinalprojmoviesapp.data.repository.AuthFBRepos.AuthReposFB
import com.example.kotlinfinalprojmoviesapp.databinding.UserRegisterBinding
import dagger.hilt.android.AndroidEntryPoint
import il.co.syntax.finalkotlinproject.utils.Loading
import il.co.syntax.finalkotlinproject.utils.Success

@AndroidEntryPoint
class RegisterFragment : Fragment() {

    private var _binding: UserRegisterBinding? = null
    private val binding get() = _binding!!
    private val viewModel: RegisterationViewModel by viewModels(){
        RegisterationViewModel.VMFactory(AuthReposFB())
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = UserRegisterBinding.inflate(inflater, container, false)
        binding.registerButton.setOnClickListener{
            viewModel.createUser(binding.usernameText?.text.toString(),binding.emailEditText?.text.toString(),
            binding.passwordEditText?.text.toString())
        }
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.RegisterStatus.observe(viewLifecycleOwner){
            when(it.status){
                is Loading -> {
                }
                is Success->{
                    Toast.makeText(requireContext(),getString(R.string.user_registered_message), Toast.LENGTH_LONG).show()
                    findNavController().navigate(com.example.kotlinfinalprojmoviesapp.R.id.action_registerFragment_to_allMoviesFragment)
                }
                is il.co.syntax.finalkotlinproject.utils.Error->{
                    Toast.makeText(requireContext(),it.status.message, Toast.LENGTH_LONG).show()
                }
            }
        }

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}