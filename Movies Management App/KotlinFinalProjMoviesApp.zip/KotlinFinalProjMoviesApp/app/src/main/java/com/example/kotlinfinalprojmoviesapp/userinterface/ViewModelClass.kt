package com.example.kotlinfinalprojmoviesapp.userinterface

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.kotlinfinalprojmoviesapp.data.model.FavoriteMoviesModel
import com.example.kotlinfinalprojmoviesapp.data.model.MovieItemInRecycler
import com.example.kotlinfinalprojmoviesapp.data.repository.AuthFBRepos.AuthReposFB
import com.example.kotlinfinalprojmoviesapp.data.repository.MovieRepository
import com.example.kotlinfinalprojmoviesapp.data.roomdb.DAO
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
    class ViewModelClass @Inject constructor(
    val moviesrepos : MovieRepository,
    val fbrepos:AuthReposFB
    ):ViewModel(){

        fun ExitAapp(){
            fbrepos.logout()
        }
        val movies = moviesrepos.getMovies()

        suspend fun addMovie(movie:MovieItemInRecycler){
            moviesrepos.addMovie(movie)
    }
        suspend fun deleteMovie(movie:MovieItemInRecycler){
        moviesrepos.deleteMovie(movie)
    }

    suspend fun deleteFavMovie(movie:FavoriteMoviesModel){
        moviesrepos.removeFavoriteMovie(movie)
    }

    val favoritemovies = moviesrepos.getFavoriteMovies()

    suspend fun addFavoriteMovie(movie:FavoriteMoviesModel){
        moviesrepos.addFavoriteMovie(movie)
    }

    suspend fun updateFavMovie(movie: FavoriteMoviesModel) {
        moviesrepos.updateFavoriteMovie(movie)
    }

    val popularmovies = moviesrepos.getPopularMovies()

    val upcomingmovies = moviesrepos.getUpcomingMovies()

    private val _ShortClickedMovie = MutableLiveData<MovieItemInRecycler>()
    val ShortClickedMovie : LiveData<MovieItemInRecycler> get() = _ShortClickedMovie

    fun SetMovieDetailsOnScreen(movie:MovieItemInRecycler){
        _ShortClickedMovie.value=movie
    }

    private val _EditFavMovie = MutableLiveData<FavoriteMoviesModel>()
    val EditFavMovie : LiveData<FavoriteMoviesModel> get() = _EditFavMovie

    fun SetEditFavMovie(movie:FavoriteMoviesModel){
        _EditFavMovie.value=movie
    }


}

