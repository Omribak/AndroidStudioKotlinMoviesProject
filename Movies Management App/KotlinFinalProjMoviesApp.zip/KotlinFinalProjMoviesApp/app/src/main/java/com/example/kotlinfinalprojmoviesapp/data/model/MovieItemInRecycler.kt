package com.example.kotlinfinalprojmoviesapp.data.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName="movies")
data class MovieItemInRecycler(
    @PrimaryKey
    val id:Int?,
    @ColumnInfo(name="name")val title:String,
    @ColumnInfo(name="movie_desc")val overview:String,
    @ColumnInfo(name="movie_photo") var poster_path:String?,
    @ColumnInfo(name="adult")val adult:Boolean?,
    @ColumnInfo(name="popularity")val popularity:Double?,
    @ColumnInfo(name="release_date")val release_date:String?,
    var isFromApi: Boolean = true) {

    }


