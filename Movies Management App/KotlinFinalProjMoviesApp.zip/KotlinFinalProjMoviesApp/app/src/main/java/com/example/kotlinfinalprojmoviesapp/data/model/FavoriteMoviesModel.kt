package com.example.kotlinfinalprojmoviesapp.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "favorite_movies")
data class FavoriteMoviesModel(
    @PrimaryKey(autoGenerate = true) val id: Long? = null,
    val title: String,
    val posterPath: String?,
)