package com.example.kotlinfinalprojmoviesapp.remote_db

import com.example.kotlinfinalprojmoviesapp.data.model.AllMovies
import com.example.kotlinfinalprojmoviesapp.data.model.PopularMovies
import com.example.kotlinfinalprojmoviesapp.data.model.UpcomingMovie
import com.example.kotlinfinalprojmoviesapp.data.model.UpcomingMovies
import retrofit2.Response
import retrofit2.http.GET

interface MoviesRetrofitService2 {
    @GET("3/movie/top_rated?api_key=9097cba17be01fbb9f3b5d56c7a054cb")
    suspend fun getAllMovies():Response<AllMovies>

    @GET("3/movie/popular?api_key=9097cba17be01fbb9f3b5d56c7a054cb")
    suspend fun getPopularMovies():Response<PopularMovies>

    @GET("3/movie/upcoming?api_key=9097cba17be01fbb9f3b5d56c7a054cb")
    suspend fun getUpcomingMovies():Response<UpcomingMovies>

}
