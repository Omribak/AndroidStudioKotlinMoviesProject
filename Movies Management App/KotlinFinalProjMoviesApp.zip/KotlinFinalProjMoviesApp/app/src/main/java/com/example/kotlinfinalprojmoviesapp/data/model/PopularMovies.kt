package com.example.kotlinfinalprojmoviesapp.data.model

data class PopularMovies (
    val results: List<PopularMovie>
){
}