package com.example.kotlinfinalprojmoviesapp.userinterface.RegisterFB

import android.util.Patterns
import androidx.lifecycle.*
import com.example.kotlinfinalprojmoviesapp.data.model.UserFB
import com.example.kotlinfinalprojmoviesapp.data.repository.AuthenticationRepository
import il.co.syntax.finalkotlinproject.utils.Resource
import kotlinx.coroutines.launch

class RegisterationViewModel(private val repository: AuthenticationRepository) :ViewModel(){
    private val _RegisterStatus = MutableLiveData<Resource<UserFB>>()

    val RegisterStatus:LiveData<Resource<UserFB>> = _RegisterStatus

    fun createUser(username:String,email:String,password:String){
        val error = if(username.isEmpty() || email.isEmpty() || password.isEmpty()){
            "No values in one of the inputs!"
        }
        else if(Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            "Invalid email!"

        }else null

        error?.let{
            _RegisterStatus.postValue(Resource.error(it))
        }
        _RegisterStatus.postValue(Resource.loading())

        viewModelScope.launch {
            val result = repository.createUser(username,email,password)
            _RegisterStatus.postValue(result)
        }
    }
    class VMFactory(private val repos:AuthenticationRepository):ViewModelProvider.NewInstanceFactory(){
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return RegisterationViewModel(repos) as T
        }
    }
}