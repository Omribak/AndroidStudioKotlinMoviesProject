package com.example.kotlinfinalprojmoviesapp.data.model

data class AllMovies (
    val results: List<MovieItemInRecycler>
        ){
}